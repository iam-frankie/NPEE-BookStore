from django.shortcuts import render, redirect  # render渲染 redirect跳转
from django.urls import reverse
from django.views.generic import View
from django.db import transaction

from .models import OrderGoods
from goods.models import GoodsSKU
from user.models import Address
from .models import OrderInfo, OrderGoods

from django.http import JsonResponse
from django_redis import get_redis_connection
from utils.mixin import LoginRequiredMixin
from datetime import datetime


# Create your views here.

# /order/place
class OrderPlaceView(LoginRequiredMixin, View):
    """提交订单页面显示"""

    def post(self, request):
        """提交订单页面显示"""
        # 获取登录的用户
        user = request.user

        # 获取参数sku_ids
        sku_ids = request.POST.getlist('sku_ids')  # [1,26]

        # 校验参数
        if not sku_ids:
            # 跳转到购物车页面
            return redirect(reverse('cart:show'))

        conn = get_redis_connection('default')
        cart_key = 'cart_%d' % user.id

        skus = []
        # 分别保存商品的总件数和总价格
        total_count = 0
        total_price = 0
        # 遍历sku_ids获取用户要购买的商品的信息
        for sku_id in sku_ids:
            # 根据商品的id获取商品的信息
            sku = GoodsSKU.objects.get(id=sku_id)
            # 获取用户所要购买的商品的数量
            count = conn.hget(cart_key, sku_id)
            # 计算商品的小计
            amount = sku.price * int(count)
            # 动态给sku增加属性count，保存购买商品的数量
            sku.count = int(count)
            # 动态给sku增加属性amount，保存购买商品的小计
            sku.amount = amount
            # 追加
            skus.append(sku)
            # 累加计算商品的总件数和总价格
            total_count += int(count)
            total_price += amount

        # 运费：实际开发时，属于一个子系统
        transit_price = 10  # 假定运费为10 实际上要综合 运送距离+购买书籍重量等因素多方面考虑

        # 实付款
        total_pay = total_price + transit_price

        # 获取用户的收件地址
        addrs = Address.objects.filter(user=user)

        # 组织上下文
        sku_ids = ','.join(sku_ids)  # [1.25]->1,25
        context = {
            'skus': skus,
            'total_price': total_price,
            'total_count': total_count,
            'transit_price': transit_price,
            'total_pay': total_pay,
            'addrs': addrs,
            'sku_ids': sku_ids
        }

        # 使用模板
        return render(request, 'place_order.html', context)


# 前端传递的参数： 地址id（addr_id) 支付方式（pay_method) 用户要购买的商品id字符串（sku_ids)
# 悲观锁
class OrderCommitView1(View):
    """订单创建"""

    @transaction.atomic  # 使用atomic装饰，将以下操作都装入一个事务，从此同生死，共进退
    def post(self, request):
        """订单创建"""
        # 判断用户是否登录
        user = request.user
        if not user.is_authenticated:
            # 用户未登录
            return JsonResponse({'res': 0, "errmsg": "用户未登录"})
        # 接收参数
        addr_id = request.POST.get('addr_id')
        pay_method = request.POST.get('pay_method')
        sku_ids = request.POST.get('sku_ids')

        # 校验参数
        if not all([addr_id, pay_method, sku_ids]):
            return JsonResponse({'res': 1, "errmsg": "信息不完整，请补充"})

        # 校验支付方式
        if pay_method not in OrderInfo.PAY_METHODS.keys():
            return JsonResponse({'res': 2, "errmsg": "支付方式非法，请重新选择"})

        # 校验地址
        try:
            addr = Address.objects.get(id=addr_id)
        except Address.DoesNotExist:
            # 地址不存在
            return JsonResponse({'res': 3, "errmsg": "地址不存在，请重新填写"})

            # todo：创建订单 核心业务

            # 组织参数
            # 订单id：订单生成时间+用户id
        order_id = datetime.now().strftime('%Y%m%d%H%M%S') + str(user.id)

        # 总数目和总金额、运费
        transit_price = 10
        total_count = 0
        total_price = 0

        # 设置事务保存点
        save_id = transaction.savepoint()

        try:
            # todo：向df_order_info 表中添加一条记录
            order = OrderInfo.objects.create(order_id=order_id,
                                             user=user,
                                             addr=addr,
                                             pay_method=pay_method,
                                             total_price=total_price,
                                             total_count=total_count,
                                             transit_price=transit_price,
                                             )

            # todo: 用户的订单中有几个商品，需要向df_order_goods表中加入几条记录
            conn = get_redis_connection('default')
            cart_key = 'cart_%d' % user.id

            sku_ids = sku_ids.split(',')  #
            for sku_id in sku_ids:
                # 获取商品的信息
                try:
                    # select *
                    # from df_goods_sku
                    # where id=sku_id for update
                    sku = GoodsSKU.objects.select_for_update().get(id=sku_id)
                    # sku = GoodsSKU.objects.get(id=sku_id)
                except:
                    # 商品不存在
                    # print(e)
                    transaction.savepoint_rollback(save_id)  # 回滚到
                    return JsonResponse({'res': 4, "errmsg": "商品不存在哦"})

                print('user%d stock%d' % (user.id, sku.stock))

                import time
                time.sleep(10)

                count = conn.hget(cart_key, sku_id)

                # todo: 判断商品的库存
                if int(count) > sku.stock:
                    transaction.savepoint_rollback(save_id)  # 回滚到
                    return JsonResponse({'res': 6, "errmsg": "商品库存不足"})

                # todo:向df_order_goods表中添加一条记录
                OrderGoods.objects.create(order=order,
                                          sku=sku,
                                          count=count,
                                          price=sku.price
                                          )

                # todo: 更新商品的库存和销量
                sku.stock -= int(count)
                sku.sales += int(count)
                sku.save()

                # todo: 累加计算订单商品的总数目和总价格
                amount = sku.price * int(count)
                total_count += int(count)
                total_price += amount

            # todo: 更新订单信息表中的商品的总数量和总价格
            order.total_count = total_count
            order.total_price = total_price
            order.save()

        except Exception as e:
            transaction.savepoint_rollback(save_id)
            return JsonResponse({'res': 7, "errmsg": "下单失败"})

        # 提交事务
        transaction.savepoint_commit(save_id)
        # todo:清除用户购物车中对应记录 例子str=[1,3]
        conn.hdel(cart_key, *sku_ids)  # 列表前加*表示将列表拆包，比如str拆包之后，将1,3传入

        # 返回应答
        return JsonResponse({'res': 5, "errmsg": "创建成功"})


# 乐观锁
class OrderCommitView(View):
    """订单创建"""

    @transaction.atomic  # 使用atomic装饰，将以下操作都装入一个事务，从此同生死，共进退
    def post(self, request):
        """订单创建"""
        # 判断用户是否登录
        user = request.user
        if not user.is_authenticated:
            # 用户未登录
            return JsonResponse({'res': 0, "errmsg": "用户未登录"})
        # 接收参数
        addr_id = request.POST.get('addr_id')
        pay_method = request.POST.get('pay_method')
        sku_ids = request.POST.get('sku_ids')

        # 校验参数
        if not all([addr_id, pay_method, sku_ids]):
            return JsonResponse({'res': 1, "errmsg": "信息不完整，请补充"})

        # 校验支付方式
        if pay_method not in OrderInfo.PAY_METHODS.keys():
            return JsonResponse({'res': 2, "errmsg": "支付方式非法，请重新选择"})

        # 校验地址
        try:
            addr = Address.objects.get(id=addr_id)
        except Address.DoesNotExist:
            # 地址不存在
            return JsonResponse({'res': 3, "errmsg": "地址不存在，请重新填写"})

            # todo：创建订单 核心业务

            # 组织参数
            # 订单id：订单生成时间+用户id
        order_id = datetime.now().strftime('%Y%m%d%H%M%S') + str(user.id)

        # 总数目和总金额、运费
        transit_price = 10
        total_count = 0
        total_price = 0

        # 设置事务保存点
        save_id = transaction.savepoint()

        try:
            # todo：向df_order_info 表中添加一条记录
            order = OrderInfo.objects.create(order_id=order_id,
                                             user=user,
                                             addr=addr,
                                             pay_method=pay_method,
                                             total_price=total_price,
                                             total_count=total_count,
                                             transit_price=transit_price,
                                             )

            # todo: 用户的订单中有几个商品，需要向df_order_goods表中加入几条记录
            conn = get_redis_connection('default')
            cart_key = 'cart_%d' % user.id

            sku_ids = sku_ids.split(',')  #
            for sku_id in sku_ids:
                for i in range(3):  # 轮询三次，若一直没货，绝大多数情况下是没货的
                    # 获取商品的信息
                    try:
                        sku = GoodsSKU.objects.get(id=sku_id)
                    except:
                        # 商品不存在
                        transaction.savepoint_rollback(save_id)  # 回滚到
                        return JsonResponse({'res': 4, "errmsg": "商品不存在哦"})

                    count = conn.hget(cart_key, sku_id)

                    # todo: 判断商品的库存
                    if int(count) > sku.stock:
                        transaction.savepoint_rollback(save_id)  # 回滚到
                        return JsonResponse({'res': 6, "errmsg": "商品库存不足"})

                    # todo: 更新商品的库存和销量
                    origin_stock = sku.stock
                    new_stock = origin_stock - int(count)
                    new_sales = sku.stock + int(count)
                    # sku.stock -= int(count)
                    # sku.sales += int(count)
                    # sku.save()

                    print('user%d stock%d' % (user.id, sku.stock))
                    import time
                    time.sleep(10)

                    # update df_goods_sku
                    # set stock = new_stock, sales = new_sales
                    # where id=sku_id and stock = origin_stock
                    # 返回受影响的行数
                    res = GoodsSKU.objects.filter(id=sku_id, stock=origin_stock).update(stock=new_stock,
                                                                                        sales=new_sales)
                    if res == 0:
                        if i == 2:      # 第三次若还没有查出库存，才进行回滚
                            transaction.savepoint_rollback(save_id)  # 直接返回，那么原来即便有充足的货物，多个消费者也不能同时购买
                            return JsonResponse({'res': 7, "errmsg": "下单失败2"})
                        continue

                    # todo:向df_order_goods表中添加一条记录
                    OrderGoods.objects.create(order=order,
                                              sku=sku,
                                              count=count,
                                              price=sku.price
                                              )

                    # todo: 累加计算订单商品的总数目和总价格
                    amount = sku.price * int(count)
                    total_count += int(count)
                    total_price += amount

            # todo: 更新订单信息表中的商品的总数量和总价格
            order.total_count = total_count
            order.total_price = total_price
            order.save()

        except Exception as e:
            transaction.savepoint_rollback(save_id)
            return JsonResponse({'res': 7, "errmsg": "下单失败"})

        # 提交事务
        transaction.savepoint_commit(save_id)
        # todo:清除用户购物车中对应记录 例子str=[1,3]
        conn.hdel(cart_key, *sku_ids)  # 列表前加*表示将列表拆包，比如str拆包之后，将1,3传入

        # 返回应答
        return JsonResponse({'res': 5, "errmsg": "创建成功"})
