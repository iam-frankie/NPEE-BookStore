from django.shortcuts import render, redirect
from django.urls import reverse  # 从Django2.0版本开始，导入reverse采用此方式
from django.core.mail import send_mail
import re
from django.http import HttpResponse
from django.views.generic import View
from .models import User
from itsdangerous import TimedJSONWebSignatureSerializer as Serializer  # 使用模块中进行Web数据加密的模块
# 两大功能 -1、加密
from itsdangerous import SignatureExpired
# -2、设置有效时限，逾期重新发送激活消息
from django.conf import settings  # 借助Django内置的settings




# Create your views here.
# 1-注册直接版
# /user/register/
def register(request):
    """显示注册界面"""
    if request.method == 'GET':
        # 显示注册页面
        return render(request, 'register.html')  # 获取请求，返回Register页面
    elif request.method == 'POST':
        """进行注册处理"""
        # 接受数据
        username = request.POST.get('user_name')
        password = request.POST.get('pwd')
        # 使用DJango自带的密码加密手法
        email = request.POST.get('email')
        allow = request.POST.get('allow')
        # 进行数据校验
        if not all([username, password, email]):  # 判断是否数据完整
            # 数据不完整
            return render(request, 'register.html', {'errmsg': '数据不完整'})
        # 校验邮箱
        if not re.match(r'^[a-z0-9][\w\.\-]*@[a-z0-9\-]+(\.[a-z]{2,5}){1,2}$', email):  # 输入的邮箱，进行正则匹配
            return render(request, 'register.html', {'errmsg': '邮箱格式不正确'})

        if allow != 'on':
            return render(request, 'register.html', {'errmsg': '请同意协议'})
        # 校验用户名是否重复
        try:
            user = User.objects.get(username=username)
        except User.DoesNotExist:
            # 用户名不存在
            user = None
        if user:
            # 用户名已存在
            return render(request, 'register.html', {'errmsg': '用户名已存在'})
        # 进行业务处理：进行用户注册
        user = User.objects.create_user(username, email, password)  # 摒弃传统注册方式，直接调用内置的存储构造方法
        user.is_active = False  # 注册状态，默认为假
        user.save()

        # 返回应答,跳转首页
        return redirect(reverse('goods:index'))
        # 调用goods里的index方法，用到了反向解析，方便调用并跳转到goods中的界面，因为默认是user/XXXX


# 2-注册优化版
# 上面已经将注册处理和加载页面进行了合并，使得URL合二为一更加简洁
def register_handle(request):
    """进行注册处理"""
    # 接受数据
    username = request.POST.get('user_name')
    password = request.POST.get('pwd')
    # 使用DJango自带的密码加密手法
    email = request.POST.get('email')
    allow = request.POST.get('allow')
    # 进行数据校验
    if not all([username, password, email]):  # 判断是否数据完整
        # 数据不完整
        return render(request, 'register.html', {'errmsg': '数据不完整'})
    # 校验邮箱
    if not re.match(r'^[a-z0-9][\w\.\-]*@[a-z0-9\-]+(\.[a-z]{2,5}){1,2}$', email):  # 输入的邮箱，进行正则匹配
        return render(request, 'register.html', {'errmsg': '邮箱格式不正确'})

    if allow != 'on':
        return render(request, 'register.html', {'errmsg': '请同意协议'})
    # 校验用户名是否重复
    try:
        user = User.objects.get(username=username)
    except User.DoesNotExist:
        # 用户名不存在
        user = None
    if user:
        # 用户名已存在
        return render(request, 'register.html', {'errmsg': '用户名已存在'})
    # 进行业务处理：进行用户注册
    user = User.objects.create_user(username, email, password)  # 摒弃传统注册方式，直接调用内置的存储构造方法
    user.is_active = False  # 注册状态，默认为假
    user.save()

    # 返回应答,跳转首页
    return redirect(reverse('goods:index'))
    # 调用goods里的index方法，用到了反向解析，方便调用并跳转到goods中的界面，因为默认是user/XXXX

# 3、注册、利用Django内置模块优化版
# /user/register
class RegisterView(View):
    '''注册类'''

    def get(self, request):
        '''显示注册页面'''
        return render(request, 'register.html')

    def post(self, request):
        '''进行注册处理'''
        # 接受数据
        username = request.POST.get('user_name')
        password = request.POST.get('pwd')
        # 使用DJango自带的密码加密手法
        email = request.POST.get('email')
        allow = request.POST.get('allow')
        # 进行数据校验
        if not all([username, password, email]):  # 判断是否数据完整
            # 数据不完整
            return render(request, 'register.html', {'errmsg': '数据不完整'})
        # 校验邮箱
        if not re.match(r'^[a-z0-9][\w\.\-]*@[a-z0-9\-]+(\.[a-z]{2,5}){1,2}$', email):  # 输入的邮箱，进行正则匹配
            return render(request, 'register.html', {'errmsg': '邮箱格式不正确'})

        if allow != 'on':
            return render(request, 'register.html', {'errmsg': '请同意协议'})
        # 校验用户名是否重复
        try:
            user = User.objects.get(username=username)
        except User.DoesNotExist:
            # 用户名不存在
            user = None
        if user:
            # 用户名已存在
            return render(request, 'register.html', {'errmsg': '用户名已存在'})
        # 进行业务处理：进行用户注册
        user = User.objects.create_user(username, email, password)  # 摒弃传统注册方式，直接调用内置的存储构造方法
        user.is_active = False  # 注册状态，默认为假
        user.save()

        # 发送激活邮件，包含激活链接：http://127.0.0.1:8000/user/active/1
        # 激活链接中需要包含用户的身份信息，并且要把身份信息进行加密
        # It's dangerous模块进行加密

        # 加密用户的身份信息，生成激活的token
        serializer = Serializer(settings.SECRET_KEY, 3600)
        info = {'confirm': user.id}
        token = serializer.dumps(info)

        # 发邮件
        subject = "研途无忧欢迎信息"
        message = '邮件正文'
        sender = settings.EMAIL_FROM        #引用setting中的Email_FROM设置
        receiver = [email]
        send_mail(subject, message, sender, receiver)
        # 返回应答,跳转首页
        return redirect(reverse('goods:index'))
        # 调用goods里的index方法，用到了反向解析，方便调用并跳转到goods中的界面，因为默认是user/XXXX


class ActiveView(View):
    """用户激活"""
    def get(self, request, token):
        """"""
        # 进行解密，获取要激活的用户信息
        serializer = Serializer(settings.SECRET_KEY, 3600)
        try:
            info = serializer.loads(token)
            user_id = info['confirm']

            # 根据id获取用户信息
            user = User.objects.get(id=user_id)
            user.is_active = 1
            user.save()

            # 跳转到登录页面
            return redirect(reverse('user:login'))
        except SignatureExpired as e:
            # 激活链接已过期
            return HttpResponse('激活链接已过期')

#/user/login
class LoginView(View):
    """登录"""
    def get(self, request):
        """显示登录页面"""
        return render(request, 'login.html')