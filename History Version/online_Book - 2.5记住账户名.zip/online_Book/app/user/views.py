from django.shortcuts import render, redirect
from django.urls import reverse  # 从Django2.0版本开始，导入reverse采用此方式
from django.core.mail import send_mail
import re
from django.http import HttpResponse
from django.views.generic import View
from .models import User
from itsdangerous import TimedJSONWebSignatureSerializer as Serializer  # 使用模块中进行Web数据加密的模块
# 两大功能 -1、加密
from itsdangerous import SignatureExpired
# -2、设置有效时限，逾期重新发送激活消息
from django.conf import settings  # 借助Django内置的settings
from celery_tasks.tasks import send_register_active_mail
from django.contrib.auth import authenticate, login  # 直接使用函数保存


# Create your views here.
# 1-注册直接版
# /user/register/
def register(request):
    """显示注册界面"""
    if request.method == 'GET':
        # 显示注册页面
        return render(request, 'register.html')  # 获取请求，返回Register页面
    elif request.method == 'POST':
        """进行注册处理"""
        # 接受数据
        username = request.POST.get('user_name')
        password = request.POST.get('pwd')
        # 使用DJango自带的密码加密手法
        email = request.POST.get('email')  # 获取名字对应HTML页面里name的名字
        allow = request.POST.get('allow')
        # 进行数据校验
        if not all([username, password, email]):  # 判断是否数据完整
            # 数据不完整
            return render(request, 'register.html', {'errmsg': '数据不完整'})
        # 校验邮箱
        if not re.match(r'^[a-z0-9][\w\.\-]*@[a-z0-9\-]+(\.[a-z]{2,5}){1,2}$', email):  # 输入的邮箱，进行正则匹配
            return render(request, 'register.html', {'errmsg': '邮箱格式不正确'})

        if allow != 'on':
            return render(request, 'register.html', {'errmsg': '请同意协议'})
        # 校验用户名是否重复
        try:
            user = User.objects.get(username=username)
        except User.DoesNotExist:
            # 用户名不存在
            user = None
        if user:
            # 用户名已存在
            return render(request, 'register.html', {'errmsg': '用户名已存在'})
        # 进行业务处理：进行用户注册
        user = User.objects.create_user(username, email, password)  # 摒弃传统注册方式，直接调用内置的存储构造方法
        user.is_active = False  # 注册状态，默认为假
        user.save()

        # 返回应答,跳转首页
        return redirect(reverse('goods:index'))
        # 调用goods里的index方法，用到了反向解析，方便调用并跳转到goods中的界面，因为默认是user/XXXX


# 2-注册优化版
# 上面已经将注册处理和加载页面进行了合并，使得URL合二为一更加简洁
def register_handle(request):
    """进行注册处理"""
    # 接受数据
    username = request.POST.get('user_name')
    password = request.POST.get('pwd')
    # 使用DJango自带的密码加密手法
    email = request.POST.get('email')
    allow = request.POST.get('allow')
    # 进行数据校验
    if not all([username, password, email]):  # 判断是否数据完整
        # 数据不完整
        return render(request, 'register.html', {'errmsg': '数据不完整'})
    # 校验邮箱
    if not re.match(r'^[a-z0-9][\w\.\-]*@[a-z0-9\-]+(\.[a-z]{2,5}){1,2}$', email):  # 输入的邮箱，进行正则匹配
        return render(request, 'register.html', {'errmsg': '邮箱格式不正确'})

    if allow != 'on':
        return render(request, 'register.html', {'errmsg': '请同意协议'})
    # 校验用户名是否重复
    try:
        user = User.objects.get(username=username)
    except User.DoesNotExist:
        # 用户名不存在
        user = None
    if user:
        # 用户名已存在
        return render(request, 'register.html', {'errmsg': '用户名已存在'})
    # 进行业务处理：进行用户注册
    user = User.objects.create_user(username, email, password)  # 摒弃传统注册方式，直接调用内置的存储构造方法
    user.is_active = False  # 注册状态，默认为假
    user.save()

    # 返回应答,跳转首页
    return redirect(reverse('goods:index'))
    # 调用goods里的index方法，用到了反向解析，方便调用并跳转到goods中的界面，因为默认是user/XXXX


# 3、注册、利用Django内置模块优化版
# /user/register
class RegisterView(View):
    '''注册类'''

    def get(self, request):
        '''显示注册页面'''
        return render(request, 'register.html')

    def post(self, request):
        '''进行注册处理'''
        # 接受数据
        username = request.POST.get('user_name')
        password = request.POST.get('pwd')
        # 使用DJango自带的密码加密手法
        email = request.POST.get('email')
        allow = request.POST.get('allow')
        # 进行数据校验
        if not all([username, password, email]):  # 判断是否数据完整
            # 数据不完整
            return render(request, 'register.html', {'errmsg': '数据不完整'})
        # 校验邮箱
        if not re.match(r'^[a-z0-9][\w\.\-]*@[a-z0-9\-]+(\.[a-z]{2,5}){1,2}$', email):  # 输入的邮箱，进行正则匹配
            return render(request, 'register.html', {'errmsg': '邮箱格式不正确'})

        if allow != 'on':
            return render(request, 'register.html', {'errmsg': '请同意协议'})
        # 校验用户名是否重复
        try:
            user = User.objects.get(username=username)
        except User.DoesNotExist:
            # 用户名不存在
            user = None
        if user:
            # 用户名已存在
            return render(request, 'register.html', {'errmsg': '用户名已存在'})
        # 进行业务处理：进行用户注册
        user = User.objects.create_user(username, email, password)  # 摒弃传统注册方式，直接调用内置的存储构造方法
        user.is_active = False  # 注册状态，默认为假
        user.save()
        print('用户新建！！！！', end='')

        # 发送激活邮件，包含激活链接：http://127.0.0.1:8000/user/active/1
        # 激活链接中需要包含用户的身份信息，并且要把身份信息进行加密
        # It's dangerous模块进行加密

        # 加密用户的身份信息，生成激活的token
        serializer = Serializer(settings.SECRET_KEY, 3600)

        info = {'confirm': user.id}
        print('用户新建成功', end='')
        print(user.id)

        token = serializer.dumps(info)  # bytes数据
        token = token.decode()  # 默认解码方式是UTF-8
        print('加密成功', end='')
        print(token)

        # 发邮件
        # send_register_active_mail.delay(email, username, token)   #delay放入任务队列
        subject = "研途无忧欢迎信息"
        message = ''
        # 使用HTML_Message才能解析HTML语言，显示出该有的样式
        html_message = '<h1>%s,欢迎您成为研途无忧注册会员</h1>' \
                       '请点击以下链接激活您的账户<br/>' \
                       '<a href="http://127.0.0.1:8000/user/active/%s">' \
                       'http://127.0.0.1:8000/user/active/%s</a>' % (username, token, token)  # 邮件正文
        sender = settings.EMAIL_FROM  # 引用setting中的Email_FROM设置
        receiver = [email]
        send_mail(subject, message, sender, receiver, html_message=html_message)

        # 返回应答,跳转首页
        return redirect(reverse('goods:index'))
        # 调用goods里的index方法，用到了反向解析，方便调用并跳转到goods中的界面，因为默认是user/XXXX


class ActiveView(View):
    """用户激活"""

    def get(self, request, token):
        """进行用户激活"""
        # 进行解密，获取要激活的用户信息
        serializer = Serializer(settings.SECRET_KEY, 3600)
        print('解密器创建成功', end='')

        try:
            info = serializer.loads(token.encode())
            user_id = info['confirm']
            print('成功获取用户id', end='')
            print(user_id)

            # 根据id获取用户信息
            user = User.objects.get(id=user_id)
            user.is_active = True
            user.save()
            print('激活成功', end='')
            # 跳转到登录页面
            return redirect(reverse('user:login'))
        except SignatureExpired as e:
            # 激活链接已过期
            return HttpResponse('激活链接已过期')


# /user/login
class LoginView(View):
    """登录"""

    def get(self, request):
        """显示登录页面"""
        # 判断是否记住了用户名
        if 'username'in request.COOKIES:
            username = request.COOKIES.get('username')
            checked = 'checked'
        else:
            username = ''
            checked = ''
        # 可以使用模板

        return render(request, 'login.html', {'username': username, 'checked': checked})

    def post(self, request):
        """登录校验"""
        # 接受数据
        username = request.POST.get('username')
        password = request.POST.get('pwd')

        # 校验数据
        if not all([username, password]):
            print(username)
            print(password)
            return render(request, 'login.html', {'errmsg': '数据不完整'})
        # 业务处理：登录校验
        # 常规操作 User.objects.get(username=username, password=password)
        user = authenticate(username=username, password=password)
        if user is not None:
            # 用户名密码正确
            if user.is_active:
                print("用户已激活")
                # 记录用户登录状态
                login(request, user)
                # 跳转到首页
                response = redirect(reverse('goods:index')) #HttpResponseRedirect

                # 判断是否需要记住用户名字
                remember = request.POST.get('remember')
                if remember == 'on':
                    # 记住用户名
                    response.set_cookie('username', username, max_age=7*24*3600)   #分配缓存，存储用户名
                else :
                    response.delete_cookie('username')
                # 返回response
                return response
            else:
                print("用户未激活")
                return render(request, 'login.html', {'errmsg': '请激活您的账户'})
        else:
            # 用户名或密码错误
            return render(request, 'login.html', {'errmsg': '用户名或密码错误'})

        # 返回应答
