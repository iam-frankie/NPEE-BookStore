from django.shortcuts import render


# Create your views here.

# /user/register/
def register(request):
    """显示注册界面"""
    return render(request, 'register.html')  # 获取请求，返回Register页面


def register_handle(request):
    """进行注册处理"""
    # 接受数据
    username = request.POST.get('user_name')
    password = request.POST.get('pwd')
    email = request.POST.get('e')
    # 进行数据校验

    # 进行业务处理：进行用户注册

    # 返回应答
