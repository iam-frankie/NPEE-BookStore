from django.urls import path
from . import views

urlpatterns = [  # 指明路径，调用的页面，还有名称
    path("register", views.register, name="register"),  # 注册
    path("register_handle", views.register_handle, name='register_handle'),  # 注册处理

]
