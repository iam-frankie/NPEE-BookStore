from django.db import models

# Create your models here.
class GoodTest(models.Model):

    STATUS_CHOICES = (
        (0, '下架'),
        (1, '上架'),
#        (0, ''),
    )
    status = models.SmallIntegerField(choices=STATUS_CHOICES, verbose_name='商品状态')
    detail = models
