from django.contrib import admin
from .models import GoodsType
# Register your models here.

admin.site.register(GoodsType)