from django.contrib import admin
from apps.Practice.models import GoodTest
# Register your models here.

admin.site.register(GoodTest)