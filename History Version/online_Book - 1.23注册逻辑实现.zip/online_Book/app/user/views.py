from django.shortcuts import render, redirect
from django.urls import reverse  # 从Django2.0版本开始，导入reverse采用此方式
import re
from django.views.generic import View
from .models import User

# Create your views here.

# /user/register/


def register(request):
    """显示注册界面"""
    if request.method == 'GET':
        # 显示注册页面
        return render(request, 'register.html')  # 获取请求，返回Register页面
    elif request.method == 'POST':
        """进行注册处理"""
        # 接受数据
        username = request.POST.get('user_name')
        password = request.POST.get('pwd')
        # 使用DJango自带的密码加密手法
        email = request.POST.get('email')
        allow = request.POST.get('allow')
        # 进行数据校验
        if not all([username, password, email]):  # 判断是否数据完整
            # 数据不完整
            return render(request, 'register.html', {'errmsg': '数据不完整'})
        # 校验邮箱
        if not re.match(r'^[a-z0-9][\w\.\-]*@[a-z0-9\-]+(\.[a-z]{2,5}){1,2}$', email):  # 输入的邮箱，进行正则匹配
            return render(request, 'register.html', {'errmsg': '邮箱格式不正确'})

        if allow != 'on':
            return render(request, 'register.html', {'errmsg': '请同意协议'})
        # 校验用户名是否重复
        try:
            user = User.objects.get(username=username)
        except User.DoesNotExist:
            # 用户名不存在
            user = None
        if user:
            # 用户名已存在
            return render(request, 'register.html', {'errmsg': '用户名已存在'})
        # 进行业务处理：进行用户注册
        user = User.objects.create_user(username, email, password)  # 摒弃传统注册方式，直接调用内置的存储构造方法
        user.is_active = False  # 注册状态，默认为假
        user.save()
        # 返回应答,跳转首页
        return redirect(reverse('goods:index'))
        # 调用goods里的index方法，用到了反向解析，方便调用并跳转到goods中的界面，因为默认是user/XXXX


# 上面已经将注册处理和加载页面进行了合并，使得URL合二为一更加简洁
def register_handle(request):
    """进行注册处理"""
    # 接受数据
    username = request.POST.get('user_name')
    password = request.POST.get('pwd')
    # 使用DJango自带的密码加密手法
    email = request.POST.get('email')
    allow = request.POST.get('allow')
    # 进行数据校验
    if not all([username, password, email]):  # 判断是否数据完整
        # 数据不完整
        return render(request, 'register.html', {'errmsg': '数据不完整'})
    # 校验邮箱
    if not re.match(r'^[a-z0-9][\w\.\-]*@[a-z0-9\-]+(\.[a-z]{2,5}){1,2}$', email):  # 输入的邮箱，进行正则匹配
        return render(request, 'register.html', {'errmsg': '邮箱格式不正确'})

    if allow != 'on':
        return render(request, 'register.html', {'errmsg': '请同意协议'})
    # 校验用户名是否重复
    try:
        user = User.objects.get(username=username)
    except User.DoesNotExist:
        # 用户名不存在
        user = None
    if user:
        # 用户名已存在
        return render(request, 'register.html', {'errmsg': '用户名已存在'})
    # 进行业务处理：进行用户注册
    user = User.objects.create_user(username, email, password)  # 摒弃传统注册方式，直接调用内置的存储构造方法
    user.is_active = False  # 注册状态，默认为假
    user.save()
    # 返回应答,跳转首页
    return redirect(reverse('goods:index'))
    # 调用goods里的index方法，用到了反向解析，方便调用并跳转到goods中的界面，因为默认是user/XXXX


#/user/register
class RegisterView(View):
    '''注册类'''
    def get(self, request):
        '''显示注册页面'''
        return render(request, 'register.html')

    def post(self, request):
        '''进行注册处理'''
        # 接受数据
        username = request.POST.get('user_name')
        password = request.POST.get('pwd')
        # 使用DJango自带的密码加密手法
        email = request.POST.get('email')
        allow = request.POST.get('allow')
        # 进行数据校验
        if not all([username, password, email]):  # 判断是否数据完整
            # 数据不完整
            return render(request, 'register.html', {'errmsg': '数据不完整'})
        # 校验邮箱
        if not re.match(r'^[a-z0-9][\w\.\-]*@[a-z0-9\-]+(\.[a-z]{2,5}){1,2}$', email):  # 输入的邮箱，进行正则匹配
            return render(request, 'register.html', {'errmsg': '邮箱格式不正确'})

        if allow != 'on':
            return render(request, 'register.html', {'errmsg': '请同意协议'})
        # 校验用户名是否重复
        try:
            user = User.objects.get(username=username)
        except User.DoesNotExist:
            # 用户名不存在
            user = None
        if user:
            # 用户名已存在
            return render(request, 'register.html', {'errmsg': '用户名已存在'})
        # 进行业务处理：进行用户注册
        user = User.objects.create_user(username, email, password)  # 摒弃传统注册方式，直接调用内置的存储构造方法
        user.is_active = False  # 注册状态，默认为假
        user.save()
        # 返回应答,跳转首页
        return redirect(reverse('goods:index'))
        # 调用goods里的index方法，用到了反向解析，方便调用并跳转到goods中的界面，因为默认是user/XXXX
