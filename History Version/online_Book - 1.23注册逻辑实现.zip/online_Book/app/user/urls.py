from django.urls import path
from . import views
from .views import RegisterView

urlpatterns = [  # 指明路径，调用的页面，还有名称
    # path("register", views.register, name="register"),  # 注册
    # path("register_handle", views.register_handle, name='register_handle'),  # 注册处理
    path("register", RegisterView.as_view(), name="register"),  # 注册-类视图注册
    # register是从父类默认继承的方法
]
