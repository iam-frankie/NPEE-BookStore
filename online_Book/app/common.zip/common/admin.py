from django.contrib import admin
from app.common.models import GoodTest
# Register your models here.

admin.site.register(GoodTest)